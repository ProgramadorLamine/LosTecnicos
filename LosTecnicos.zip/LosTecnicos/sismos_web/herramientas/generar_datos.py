import sys, json, base64, io
from pathlib import Path
RAIZ = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(RAIZ / "herramientas"))
import numpy as np, pandas as pd
import modelo_sismos as a
from matplotlib.figure import Figure

"""Genera js/datos.js y graficas/*.png a partir del Excel (datos/reporte1417.xlsx).
Solo hace falta ejecutarlo si cambia el Excel; la página web NO lo necesita."""
E = a.preparar([RAIZ / "datos" / "reporte1417.xlsx"]); df, tabla, m, imp, modelo = E["df"], E["tabla"], E["m"], E["imp"], E["modelo"]
NIV = a.NIVELES
(RAIZ / "graficas").mkdir(exist_ok=True)
def b64(fig, n=[0]):
    n[0] += 1
    ruta = f"graficas/{n[0]:02d}.png"
    (RAIZ / ruta).write_bytes(a.png(fig))
    return ruta

# --- gráficas (PNG embebidas)
graf = [{"n": n, "img": b64(f), "obs": o} for (n, f), o in zip(a.graficas(E), a.OBSERVACIONES)]
fig = Figure(figsize=(4.6, 4.2), dpi=100); ax = fig.add_subplot(111)
ax.imshow(m["matriz"], cmap="Blues"); ax.set_xticks(range(3)); ax.set_xticklabels(NIV); ax.set_yticks(range(3)); ax.set_yticklabels(NIV)
for i in range(3):
    for j in range(3):
        ax.text(j, i, int(m["matriz"][i][j]), ha="center", va="center", color="white" if m["matriz"][i][j] > m["matriz"].max()/2 else "black", fontsize=13)
ax.set_xlabel("Predicho"); ax.set_ylabel("Real"); ax.set_title("Matriz de confusión (prueba 20 %)", loc="left", fontweight="bold")
graf.append({"n": "Matriz de confusión", "img": b64(fig), "obs": "Filas = nivel real, columnas = nivel predicho (conjunto de prueba, 20 %). La diagonal son los aciertos."})
fig = Figure(figsize=(6.5, 4.6), dpi=100); ax = fig.add_subplot(111)
s = imp.sort_values(); ax.barh(s.index, s.values, color="#2a78d6"); ax.set_title("Importancia de las variables", loc="left", fontweight="bold"); ax.grid(axis="y", visible=False)
graf.append({"n": "Importancia de variables", "img": b64(fig), "obs": "Qué variables usó más el modelo. La distancia al Nido de Bucaramanga y la actividad previa e histórica pesan más."})

# --- predicciones del modelo para cada municipio-mes
proba = modelo.predict_proba(tabla[a.FEATURES]); cl = list(modelo.classes_)
pred = {}
for i, r in tabla.iterrows():
    p = [round(float(proba[i][cl.index(n)]), 3) for n in NIV]
    pred[f"{r.municipio}|{r.mes}"] = [*p, NIV.index(r.nivel), round(float(r.mag_max_mes), 1), int(r.n_mes), 1 if i in E["idx_train"] else 0]
g = df.groupby(["municipio", df["mes"].astype(str)])["ml"].agg(["size", "max"])
act = {f"{k[0]}|{k[1]}": [int(v["size"]), round(float(v["max"]), 1)] for k, v in g.iterrows()}

# --- sismos para la tabla
d = df.sort_values("fecha_hora", ascending=False)
muns = sorted(df["municipio"].unique()); mi = {x: i for i, x in enumerate(muns)}
ev = [[str(r.fecha_hora), mi[r.municipio], round(r.latitud, 3), round(r.longitud, 3),
       None if pd.isna(r.prof) else round(r.prof, 1), round(r.ml, 1), None if pd.isna(r.fases) else int(r.fases),
       None if pd.isna(r.rms) else round(r.rms, 2), None if pd.isna(r.gap) else int(r.gap)] for r in d.itertuples()]

rep = m["reporte"]
DATA = {"mun": muns, "meses": E["meses"], "pred": pred, "act": act, "ev": ev, "graf": graf,
        "periodo": [str(df["fecha_hora"].min().date()), str(df["fecha_hora"].max().date())], "n_crudo": E["n_crudo"], "n_limpio": len(df),
        "n_obs": len(tabla), "clases": tabla["nivel"].value_counts().reindex(NIV).tolist(), "archivo": E["archivo"],
        "m": {"acc": m["acc"], "f1": m["f1"], "acc_may": m["acc_mayoria"], "f1_may": m["f1_mayoria"], "acc_per": m["acc_persist"], "f1_per": m["f1_persist"],
              "n_train": m["n_train"], "n_test": m["n_test"], "matriz": m["matriz"].tolist(),
              "rep": {n: [round(rep[n]["precision"], 2), round(rep[n]["recall"], 2), round(rep[n]["f1-score"], 2), int(rep[n]["support"])] for n in NIV},
              "imp": [[k, round(float(v), 3)] for k, v in imp.head(8).items()]}}
(RAIZ / "js" / "datos.js").write_text("/* Datos generados a partir del Excel del SGC (herramientas/generar_datos.py) */\nconst D = " + json.dumps(DATA, ensure_ascii=False, separators=(",", ":")) + ";\n", encoding="utf-8")
print("datos.js listo:", len(pred), "predicciones;", len(ev), "sismos;", len(graf), "gráficas")
