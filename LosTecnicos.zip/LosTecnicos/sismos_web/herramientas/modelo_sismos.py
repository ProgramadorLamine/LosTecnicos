"""
RETO ML SISMOS · Nivel Básico · Actividad sísmica en Santander (bajo / medio / alto)
Un solo archivo. En VS Code: abra este archivo y pulse el botón ▶ (Run Python File) de arriba a la derecha.

Qué hace: lee el Excel del SGC, lo limpia, entrena el modelo (80/20) y abre una interfaz en el navegador con
  - Clasificar (municipio + mes), historial de búsquedas y cambio de tono de color
  - Base de datos (el Excel), Gráficas y Métricas del modelo
NO usa Gradio: la interfaz es Python puro (funciona también con Python 3.14/3.15).
El Excel puede estar en cualquier carpeta cercana (este archivo, Descargas, Escritorio...). Si no lo halla, abre un cuadro para elegirlo.
Las librerías que falten se instalan solas la primera vez (tarda unos minutos).
"""
import io
import sys
import importlib
import subprocess
import zipfile
from datetime import datetime
from pathlib import Path

RUTA_EXCEL = ""   # opcional: pegue aquí la ruta completa del Excel, por ejemplo r"C:\Users\usuario\Downloads\reporte1417.xlsx"


def _asegurar_librerias():
    paquetes = [("numpy", "numpy"), ("pandas", "pandas"), ("sklearn", "scikit-learn"),
                ("matplotlib", "matplotlib"), ("openpyxl", "openpyxl")]
    faltan = []
    for modulo, pip in paquetes:
        try:
            importlib.import_module(modulo)
        except ImportError:
            faltan.append(pip)
    if faltan:
        print("Instalando librerías que faltan:", ", ".join(faltan), "(solo la primera vez, puede tardar unos minutos)...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install", "-q", *faltan])
        except subprocess.CalledProcessError:
            v = f"{sys.version_info.major}.{sys.version_info.minor}"
            sys.exit("\n*** No se pudieron instalar las librerías. Ejecute en la terminal:\n"
                     "    python -m pip install numpy pandas scikit-learn matplotlib openpyxl\n"
                     "y vuelva a ejecutar este archivo. ***\n")
        print("Librerías listas.")


_asegurar_librerias()

import numpy as np
import pandas as pd
from matplotlib.figure import Figure
from sklearn.dummy import DummyClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline

NIVELES = ["bajo", "medio", "alto"]
UMBRAL_MEDIO, UMBRAL_ALTO = 3.0, 4.0      # Ml máx del mes: <3,0 bajo | 3,0-3,9 medio | >=4,0 alto
SEMILLA = 42
AQUI = Path(__file__).resolve().parent


# ----------------------------------------------------------------------------- 1. LECTURA
def leer_excel(ruta):
    """El Excel del SGC trae un color inválido en styles.xml y openpyxl falla: se repara en memoria."""
    try:
        return pd.read_excel(ruta)
    except ValueError:
        zin, buf = zipfile.ZipFile(ruta), io.BytesIO()
        with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zout:
            for it in zin.infolist():
                datos = zin.read(it.filename)
                if it.filename == "xl/styles.xml":
                    datos = datos.replace(b'rgb="FFF"', b'rgb="FFFFFFFF"')
                zout.writestr(it, datos)
        buf.seek(0)
        return pd.read_excel(buf)


def es_catalogo(ruta):
    try:
        return "MAGNITUD Ml" in leer_excel(ruta).columns
    except Exception:
        return False


def buscar_excel():
    """Busca el Excel del SGC (cualquier nombre .xlsx) en varias carpetas. Si no lo halla, abre un cuadro para elegirlo."""
    if len(sys.argv) > 1 and sys.argv[1].lower().endswith(".xlsx"):
        return [Path(sys.argv[1])]
    if RUTA_EXCEL:
        return [Path(RUTA_EXCEL)]
    home = Path.home()
    sitios = [AQUI, Path.cwd(), AQUI / "data" / "raw", AQUI.parent, home / "Downloads", home / "Descargas",
              home / "Desktop", home / "Escritorio", home / "Documents", home / "Documentos"]
    vistos, cand = set(), []
    for carpeta in sitios:
        if carpeta.exists():
            for f in sorted(carpeta.glob("*.xlsx")):
                if not f.name.startswith("~$") and f not in vistos:
                    vistos.add(f); cand.append(f)
    for f in sorted(AQUI.rglob("*.xlsx"))[:20]:
        if not f.name.startswith("~$") and f not in vistos:
            vistos.add(f); cand.append(f)
    cand.sort(key=lambda f: "reporte" not in f.name.lower())      # primero los que dicen "reporte"
    for f in cand:
        if es_catalogo(f):
            return [f]
    try:                                                           # último recurso: elegirlo con el mouse
        import tkinter as tk
        from tkinter import filedialog
        raiz = tk.Tk(); raiz.withdraw(); raiz.attributes("-topmost", True)
        ruta = filedialog.askopenfilename(title="Elija el Excel del catálogo sísmico (SGC)", filetypes=[("Excel", "*.xlsx")])
        raiz.destroy()
        if ruta:
            return [Path(ruta)]
    except Exception:
        pass
    raise FileNotFoundError("No encontré el Excel. Pegue su ruta completa en RUTA_EXCEL (arriba en este archivo) y ejecute de nuevo.")


# ----------------------------------------------------------------------------- 2. LIMPIEZA
RENOMBRAR = {"FECHA": "fecha", "HORA_UTC": "hora", "LATITUD (grados)": "latitud", "LONGITUD (grados)": "longitud",
             "PROFUNDIDAD (Km)": "prof", "MAGNITUD Ml": "ml", "MUNICIPIO": "municipio", "# FASES": "fases",
             "RMS (Seg)": "rms", "GAP (grados)": "gap", "ERROR LATITUD (Km)": "elat", "ERROR LONGITUD (Km)": "elon"}


def limpiar(crudo):
    df = crudo.rename(columns=RENOMBRAR)[list(RENOMBRAR.values())].copy()
    for c in ["latitud", "longitud", "prof", "ml", "fases", "rms", "gap", "elat", "elon"]:
        df[c] = pd.to_numeric(df[c], errors="coerce")
    df["fecha_hora"] = pd.to_datetime(df["fecha"].astype(str) + " " + df["hora"].astype(str), errors="coerce")
    df = df.dropna(subset=["fecha_hora", "latitud", "longitud", "ml", "municipio"])   # sin fecha, coordenadas o magnitud
    df = df.drop_duplicates(subset=["fecha_hora", "latitud", "longitud"])               # duplicados
    df.loc[df["prof"] == 0, "prof"] = np.nan                                            # profundidad 0 = no resuelta
    df["error_horiz"] = df[["elat", "elon"]].mean(axis=1)
    df["mes"] = df["fecha_hora"].dt.to_period("M")
    return df.drop(columns=["fecha", "hora"]).sort_values("fecha_hora").reset_index(drop=True)


# ----------------------------------------------------------------------------- 3. TABLA DEL MODELO (municipio x mes)
def nivel(m):
    return "alto" if m >= UMBRAL_ALTO else ("medio" if m >= UMBRAL_MEDIO else "bajo")


def haversine(lat1, lon1, lat2, lon2):
    p1, p2 = np.radians(lat1), np.radians(lat2)
    a = np.sin((p2 - p1) / 2) ** 2 + np.cos(p1) * np.cos(p2) * np.sin(np.radians(lon2 - lon1) / 2) ** 2
    return 2 * 6371.0 * np.arcsin(np.sqrt(a))


FEATURES = ["n_sismos_prev", "mag_max_prev", "mag_media_prev", "n_m3_prev", "prof_media_prev", "rms_medio_prev",
            "gap_medio_prev", "error_horiz_prev", "fases_medias_prev", "n_sismos_hist", "mag_max_hist",
            "meses_activos_hist", "lat_centro", "lon_centro", "dist_nido_km"]


def construir_tabla(df):
    """Fila = municipio x mes con >=1 sismo. ENTRADAS: mes anterior + historial + ubicación.
    ETIQUETA: nivel del mes según su magnitud máxima (que NO es entrada: no hay fuga de información)."""
    agg = df.groupby(["municipio", "mes"]).agg(
        n=("ml", "size"), mx=("ml", "max"), md=("ml", "mean"), n3=("ml", lambda s: int((s >= UMBRAL_MEDIO).sum())),
        prof=("prof", "mean"), rms=("rms", "mean"), gap=("gap", "mean"), eh=("error_horiz", "mean"), fas=("fases", "mean"))
    meses = pd.period_range(df["mes"].min(), df["mes"].max(), freq="M")
    idx = pd.MultiIndex.from_product([sorted(df["municipio"].unique()), meses], names=["municipio", "mes"])
    p = agg.reindex(idx)
    for c in ["n", "mx", "md", "n3"]:
        p[c] = p[c].fillna(0)
    p["activo"] = (p["n"] > 0).astype(int)
    g = p.groupby(level="municipio")
    out = pd.DataFrame(index=p.index)
    out["n_sismos_prev"], out["mag_max_prev"], out["mag_media_prev"], out["n_m3_prev"] = (g[c].shift(1) for c in ["n", "mx", "md", "n3"])
    out["prof_media_prev"], out["rms_medio_prev"], out["gap_medio_prev"] = (g[c].shift(1) for c in ["prof", "rms", "gap"])
    out["error_horiz_prev"], out["fases_medias_prev"] = g["eh"].shift(1), g["fas"].shift(1)
    out["n_sismos_hist"] = g["n"].cumsum() - p["n"]
    out["mag_max_hist"] = g["mx"].cummax().groupby(level="municipio").shift(1)
    out["meses_activos_hist"] = g["activo"].cumsum() - p["activo"]
    out = out.reset_index()
    cen = df.groupby("municipio")[["latitud", "longitud"]].mean().rename(columns={"latitud": "lat_centro", "longitud": "lon_centro"})
    out = out.merge(cen, left_on="municipio", right_index=True)
    s = df[df["municipio"] == "LOS_SANTOS"]                                  # centro del Nido de Bucaramanga
    out["dist_nido_km"] = haversine(out["lat_centro"], out["lon_centro"], s["latitud"].median(), s["longitud"].median())
    out["n_mes"] = p["n"].values
    out["mag_max_mes"] = p["mx"].values
    out = out[(out["n_mes"] > 0) & out["n_sismos_prev"].notna()].reset_index(drop=True)
    out["nivel"] = out["mag_max_mes"].map(nivel)
    return out


# ----------------------------------------------------------------------------- 4. MODELO
def entrenar(tabla):
    X, y = tabla[FEATURES], tabla["nivel"]
    X_tr, X_te, y_tr, y_te = train_test_split(X, y, test_size=0.2, stratify=y, random_state=SEMILLA)   # 80 / 20
    modelo = make_pipeline(SimpleImputer(strategy="median"),
                           RandomForestClassifier(n_estimators=300, min_samples_leaf=2, class_weight="balanced",
                                                  random_state=SEMILLA, n_jobs=-1)).fit(X_tr, y_tr)
    pred = modelo.predict(X_te)
    base = DummyClassifier(strategy="most_frequent").fit(X_tr, y_tr).predict(X_te)
    persist = X_te["mag_max_prev"].map(nivel)                                 # línea base: repetir el nivel del mes anterior
    m = {"n_train": len(X_tr), "n_test": len(X_te),
         "acc": accuracy_score(y_te, pred), "f1": f1_score(y_te, pred, average="macro", zero_division=0),
         "acc_mayoria": accuracy_score(y_te, base), "f1_mayoria": f1_score(y_te, base, average="macro", zero_division=0),
         "acc_persist": accuracy_score(y_te, persist), "f1_persist": f1_score(y_te, persist, average="macro", zero_division=0),
         "reporte": classification_report(y_te, pred, labels=NIVELES, output_dict=True, zero_division=0),
         "matriz": confusion_matrix(y_te, pred, labels=NIVELES)}
    imp = pd.Series(modelo[-1].feature_importances_, index=FEATURES).sort_values(ascending=False)
    return modelo, set(X_tr.index), m, imp


def texto_metricas(m, imp, tabla):
    r, c = m["reporte"], m["matriz"]
    L = [f"### Modelo: Random forest · {len(tabla)} observaciones (municipio × mes) · entrenamiento {m['n_train']} / prueba {m['n_test']} (80/20)",
         f"**Exactitud (prueba):** {m['acc']:.3f} · **F1 macro:** {m['f1']:.3f}", "",
         "| Referencia | Exactitud | F1 macro |", "|---|---|---|",
         f"| Siempre «bajo» | {m['acc_mayoria']:.3f} | {m['f1_mayoria']:.3f} |",
         f"| Repetir nivel del mes anterior | {m['acc_persist']:.3f} | {m['f1_persist']:.3f} |",
         f"| **Random forest** | **{m['acc']:.3f}** | **{m['f1']:.3f}** |", "",
         "| Nivel | Precisión | Recall | F1 | Casos |", "|---|---|---|---|---|"]
    L += [f"| {n} | {r[n]['precision']:.2f} | {r[n]['recall']:.2f} | {r[n]['f1-score']:.2f} | {int(r[n]['support'])} |" for n in NIVELES]
    L += ["", "**Matriz de confusión** (filas = real, columnas = predicho)", "", "| real \\ predicho | bajo | medio | alto |", "|---|---|---|---|"]
    L += [f"| {n} | {c[i][0]} | {c[i][1]} | {c[i][2]} |" for i, n in enumerate(NIVELES)]
    L += ["", "**Variables más importantes:** " + ", ".join(f"{k} ({v:.2f})" for k, v in imp.head(5).items()), "",
          "_Nota: si la exactitud no supera a «siempre bajo» es porque la mayoría de los casos son «bajo»; por eso se reporta también el F1 macro._"]
    return "\n".join(L)


# ----------------------------------------------------------------------------- 5. PREPARAR TODO
def preparar(rutas=None):
    rutas = rutas or buscar_excel()
    print("Excel:", rutas[0])
    crudo = pd.concat([leer_excel(r) for r in rutas], ignore_index=True)
    df = limpiar(crudo)
    tabla = construir_tabla(df)
    modelo, idx_train, m, imp = entrenar(tabla)
    return {"df": df, "tabla": tabla, "modelo": modelo, "idx_train": idx_train, "m": m, "imp": imp,
            "mun": sorted(df["municipio"].unique()), "archivo": rutas[0].name, "n_crudo": len(crudo),
            "meses": [str(x) for x in pd.period_range(df["mes"].min(), df["mes"].max(), freq="M")]}


def clasificar(E, municipio_vis, mes):
    """Entrada: municipio y mes. Salida: (probabilidades, texto)."""
    municipio = municipio_vis.replace(" ", "_")
    ev = E["df"][(E["df"]["municipio"] == municipio) & (E["df"]["mes"].astype(str) == mes)]
    if ev.empty:
        return None, f"No hay sismos registrados en {municipio_vis} durante {mes}."
    t = E["tabla"]
    fila = t[(t["municipio"] == municipio) & (t["mes"].astype(str) == mes)]
    if fila.empty:
        return None, f"{mes} es el primer mes del catálogo: no hay mes previo para clasificar {municipio_vis}."
    proba = E["modelo"].predict_proba(fila[FEATURES])[0]
    pr = {c: float(p) for c, p in zip(E["modelo"].classes_, proba)}
    pred = max(pr, key=pr.get)
    real = fila["nivel"].iloc[0]
    conjunto = "entrenamiento" if fila.index[0] in E["idx_train"] else "prueba (el modelo NO lo vio al entrenar)"
    texto = (f"Nivel predicho: {pred.upper()}\n"
             f"Nivel real del catálogo: {real.upper()} (mayor sismo del mes: M {fila['mag_max_mes'].iloc[0]:.1f}, {int(fila['n_mes'].iloc[0])} sismos)\n"
             f"Conjunto: {conjunto}")
    return pr, texto


# ----------------------------------------------------------------------------- 5. PREPARAR TODO
def preparar(rutas=None):
    rutas = rutas or buscar_excel()
    print("Excel:", rutas[0])
    crudo = pd.concat([leer_excel(r) for r in rutas], ignore_index=True)
    df = limpiar(crudo)
    tabla = construir_tabla(df)
    modelo, idx_train, m, imp = entrenar(tabla)
    return {"df": df, "tabla": tabla, "modelo": modelo, "idx_train": idx_train, "m": m, "imp": imp,
            "mun": sorted(df["municipio"].unique()), "archivo": rutas[0].name, "n_crudo": len(crudo),
            "meses": [str(x) for x in pd.period_range(df["mes"].min(), df["mes"].max(), freq="M")]}


def clasificar(E, municipio_vis, mes):
    """Entrada: municipio y mes. Salida: dict con probabilidades, nivel predicho, nivel real y texto."""
    municipio = municipio_vis.replace(" ", "_")
    ev = E["df"][(E["df"]["municipio"] == municipio) & (E["df"]["mes"].astype(str) == mes)]
    if ev.empty:
        return {"ok": False, "texto": f"No hay sismos registrados en {municipio_vis} durante {mes}."}
    t = E["tabla"]
    fila = t[(t["municipio"] == municipio) & (t["mes"].astype(str) == mes)]
    if fila.empty:
        return {"ok": False, "texto": f"{mes} es el primer mes del catálogo: no hay mes previo para clasificar {municipio_vis}."}
    proba = E["modelo"].predict_proba(fila[FEATURES])[0]
    pr = {c: float(p) for c, p in zip(E["modelo"].classes_, proba)}
    pred = max(pr, key=pr.get)
    real = fila["nivel"].iloc[0]
    conjunto = "entrenamiento" if fila.index[0] in E["idx_train"] else "prueba"
    detalle = f"mayor sismo del mes: M {fila['mag_max_mes'].iloc[0]:.1f}, {int(fila['n_mes'].iloc[0])} sismos"
    texto = (f"Nivel predicho: {pred.upper()}\nNivel real del catálogo: {real.upper()} ({detalle})\n"
             f"Conjunto: {conjunto}" + (" (el modelo NO lo vio al entrenar)" if conjunto == "prueba" else ""))
    return {"ok": True, "pr": pr, "pred": pred, "real": real, "conjunto": conjunto, "texto": texto}


# ----------------------------------------------------------------------------- 6. GRÁFICAS (sin pyplot)
AZUL = "#2a78d6"
COLOR = {"bajo": "#2a78d6", "medio": "#eda100", "alto": "#e34948"}


def _fig(titulo, ancho=6.5, alto=3.8):
    fig = Figure(figsize=(ancho, alto), dpi=100, facecolor="white")
    ax = fig.add_subplot(111)
    ax.set_title(titulo, loc="left", fontweight="bold")
    ax.grid(True, color="#ececE8"); ax.set_axisbelow(True)
    ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
    return fig, ax


def graficas(E):
    df, tabla = E["df"], E["tabla"]
    figs = []
    fig, ax = _fig("Sismos por año (2018: solo enero y febrero)")
    pa = df.groupby(df["fecha_hora"].dt.year).size()
    b = ax.bar(pa.index.astype(str), pa.values, color=AZUL, width=0.6); b[-1].set_hatch("//"); b[-1].set_alpha(0.55)
    for r, v in zip(b, pa.values):
        ax.text(r.get_x() + r.get_width() / 2, v + 120, f"{v:,}".replace(",", "."), ha="center", fontsize=9)
    ax.set_ylabel("Sismos"); ax.grid(axis="x", visible=False); figs.append(("Sismos por año", fig))

    fig, ax = _fig("Histograma de magnitudes Ml (líneas: 3,0 y 4,0)")
    ax.hist(df["ml"], bins=np.arange(0, 6.6, 0.2), color=AZUL, edgecolor="white"); ax.set_yscale("log")
    for u in (3.0, 4.0):
        ax.axvline(u, color="#52514e", ls="--", lw=1)
    ax.set_xlabel("Magnitud Ml"); ax.set_ylabel("Sismos (escala log)"); figs.append(("Histograma de magnitudes", fig))

    fig, ax = _fig("Epicentros: latitud y longitud", 5.6, 5.6)
    for nombre, mask, sz, al in [("bajo (Ml<3)", df["ml"] < 3, 3, .25), ("medio (3 a 3,9)", (df["ml"] >= 3) & (df["ml"] < 4), 14, 1),
                                 ("alto (Ml>=4)", df["ml"] >= 4, 32, 1)]:
        ax.scatter(df.loc[mask, "longitud"], df.loc[mask, "latitud"], s=sz, alpha=al, color=COLOR[nombre.split()[0]],
                   label=f"{nombre}: {int(mask.sum())}", linewidths=0)
    ax.set_xlabel("Longitud"); ax.set_ylabel("Latitud"); ax.legend(frameon=False, markerscale=2, fontsize=8)
    figs.append(("Latitud y longitud (epicentros)", fig))

    fig, ax = _fig("10 municipios con más sismos")
    top = df["municipio"].value_counts().head(10).iloc[::-1]
    ax.barh([x.replace("_", " ").title() for x in top.index], top.values, color=AZUL); ax.grid(axis="y", visible=False)
    figs.append(("Municipios con más sismos", fig))

    fig, ax = _fig("Nivel de actividad (municipio x mes)", 5.5, 3.6)
    c = tabla["nivel"].value_counts().reindex(NIVELES)
    ax.bar(NIVELES, c.values, color=[COLOR[n] for n in NIVELES], width=0.55)
    for i, v in enumerate(c.values):
        ax.text(i, v + 15, str(v), ha="center")
    ax.grid(axis="x", visible=False); figs.append(("Distribución del nivel", fig))
    return figs


OBSERVACIONES = ["Los sismos por año suben de 2015 a 2017; 2018 solo trae enero y febrero, por eso no es comparable.",
                 "La mayoría son pequeños (mediana Ml 1,6): solo 835 llegan a Ml 3 y 90 a Ml 4; por eso «alto» es una clase rara.",
                 "Los epicentros se concentran en el Nido de Bucaramanga (Los Santos), que aporta más de la mitad de los sismos.",
                 "Los Santos tiene muchísimos más sismos que cualquier otro municipio.",
                 "El problema está desbalanceado: casi todos los municipio-mes son «bajo»."]


def png(fig):
    buf = io.BytesIO()
    fig.savefig(buf, format="png", bbox_inches="tight")
    return buf.getvalue()


# ----------------------------------------------------------------------------- 7. SERVIDOR + INTERFAZ WEB
import json
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlparse, parse_qs

E = {}
GRAFS = []
COLS_DATOS = ["fecha_hora", "municipio", "latitud", "longitud", "prof", "ml", "fases", "rms", "gap"]

PAGINA = """<!doctype html><html lang="es"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Actividad sísmica en Santander</title>
<style>
:root{--c:#2a78d6}
*{box-sizing:border-box} body{font-family:Segoe UI,system-ui,sans-serif;margin:0;background:#f4f5f7;color:#1c1c1c}
header{background:#fff;border-bottom:3px solid var(--c);padding:14px 24px;display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:10px}
h1{margin:0;font-size:22px;color:var(--c)} .sub{color:#555;font-size:14px;margin-top:4px}
main{max-width:1050px;margin:0 auto;padding:16px 24px 40px}
.tabs{display:flex;gap:6px;margin:14px 0;flex-wrap:wrap} .tabs button{border:0;background:#e3e5e9;padding:9px 16px;border-radius:8px;cursor:pointer;font-size:14px}
.tabs button.on{background:var(--c);color:#fff} .panel{display:none;background:#fff;border-radius:10px;padding:18px;box-shadow:0 1px 3px #0002} .panel.on{display:block}
label{display:block;font-size:13px;color:#555;margin:10px 0 4px} select{padding:8px;border:1px solid #bbb;border-radius:6px;font-size:15px;min-width:230px;background:#fff}
.btn{background:var(--c);color:#fff;border:0;border-radius:8px;padding:10px 22px;font-size:15px;cursor:pointer;margin-top:14px} .btn.gris{background:#777;padding:6px 14px;font-size:13px;margin-top:8px}
.fila{display:flex;gap:30px;flex-wrap:wrap} .col{flex:1;min-width:280px}
.barra{display:flex;align-items:center;gap:8px;margin:7px 0;font-size:14px} .barra .n{width:60px} .barra .p{width:50px;text-align:right}
.pista{flex:1;background:#e9ebee;border-radius:5px;height:18px;overflow:hidden} .rel{height:100%;width:0;transition:width .3s}
#res{white-space:pre-line;background:#f4f5f7;border-radius:8px;padding:12px;margin-top:10px;min-height:70px;font-size:14px}
#nivel{font-size:30px;font-weight:700;margin:6px 0}
table{border-collapse:collapse;width:100%;font-size:13px} th{background:var(--c);color:#fff;padding:6px;text-align:left;position:sticky;top:0} td{padding:5px 6px;border-bottom:1px solid #e5e5e5}
.scroll{max-height:420px;overflow:auto} img{max-width:100%} pre{white-space:pre-wrap;font-size:13px;background:#f4f5f7;padding:12px;border-radius:8px}
.nota{color:#555;font-size:13px}
</style></head><body>
<header><div><h1>Nivel de actividad sísmica en Santander</h1>
<div class="sub">Elige un municipio y un mes: el modelo clasifica la actividad como <b>bajo</b>, <b>medio</b> o <b>alto</b>.</div></div>
<div><label style="margin:0">Tono de color</label><select id="tono"></select></div></header>
<main>
<div class="tabs"><button class="on" data-t="t1">Clasificar</button><button data-t="t2">Base de datos (Excel)</button><button data-t="t3">Gráficas</button><button data-t="t4">Métricas del modelo</button></div>

<section id="t1" class="panel on"><div class="fila"><div class="col">
<label>Municipio</label><select id="mun"></select><label>Mes (AAAA-MM)</label><select id="mes"></select><br><button class="btn" id="go">Clasificar</button></div>
<div class="col"><div id="nivel">—</div>
<div class="barra"><span class="n">bajo</span><div class="pista"><div class="rel" id="b-bajo" style="background:#2a78d6"></div></div><span class="p" id="p-bajo">0%</span></div>
<div class="barra"><span class="n">medio</span><div class="pista"><div class="rel" id="b-medio" style="background:#eda100"></div></div><span class="p" id="p-medio">0%</span></div>
<div class="barra"><span class="n">alto</span><div class="pista"><div class="rel" id="b-alto" style="background:#e34948"></div></div><span class="p" id="p-alto">0%</span></div>
<div id="res">Elige un municipio y un mes y pulsa Clasificar.</div></div></div>
<h3>Historial de búsquedas</h3><div class="scroll" style="max-height:240px"><table id="hist"><thead><tr><th>Hora</th><th>Municipio</th><th>Mes</th><th>Predicho</th><th>Real</th><th>Conjunto</th></tr></thead><tbody></tbody></table></div>
<button class="btn gris" id="borrar">Borrar historial</button></section>

<section id="t2" class="panel"><p id="arch"></p><label>Filtrar por municipio</label><select id="fmun"></select><p class="nota" id="dinfo"></p>
<div class="scroll"><table id="datos"></table></div></section>

<section id="t3" class="panel"><label>Gráfica</label><select id="gsel"></select><p class="nota" id="gobs"></p><img id="gimg" alt="gráfica"></section>
<section id="t4" class="panel"><pre id="met"></pre></section>
</main>
<script>
const $=id=>document.getElementById(id), NIV=['bajo','medio','alto'];
const COL={'Azul':'#2a78d6','Verde':'#1baf7a','Naranja':'#eb6834','Morado':'#6250d6','Rojo':'#e34948','Gris':'#52514e'};
const CN={bajo:'#2a78d6',medio:'#c98500',alto:'#e34948'}; let hist=[];
const opt=(sel,vals,def)=>{sel.innerHTML=vals.map(v=>`<option${v===def?' selected':''}>${v}</option>`).join('')};
const j=u=>fetch(u).then(r=>r.json());
document.querySelectorAll('.tabs button').forEach(b=>b.onclick=()=>{document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('on'));
 document.querySelectorAll('.panel').forEach(x=>x.classList.remove('on'));b.classList.add('on');$(b.dataset.t).classList.add('on')});
opt($('tono'),Object.keys(COL),'Azul'); $('tono').onchange=()=>document.documentElement.style.setProperty('--c',COL[$('tono').value]);
function pintaHist(){$('hist').querySelector('tbody').innerHTML=hist.map(f=>'<tr>'+f.map(x=>`<td>${x}</td>`).join('')+'</tr>').join('')}
$('borrar').onclick=()=>{hist=[];pintaHist()};
$('go').onclick=async()=>{
 const r=await j('/api/clasificar?mun='+encodeURIComponent($('mun').value)+'&mes='+$('mes').value);
 const hora=new Date().toLocaleTimeString();
 NIV.forEach(n=>{const p=r.ok?r.pr[n]*100:0;$('b-'+n).style.width=p+'%';$('p-'+n).textContent=p.toFixed(0)+'%'});
 $('res').textContent=r.texto;
 if(r.ok){$('nivel').textContent=r.pred.toUpperCase();$('nivel').style.color=CN[r.pred];hist.unshift([hora,$('mun').value,$('mes').value,r.pred.toUpperCase(),r.real.toUpperCase(),r.conjunto])}
 else{$('nivel').textContent='—';$('nivel').style.color='#888';hist.unshift([hora,$('mun').value,$('mes').value,'sin datos','-','-'])}
 hist=hist.slice(0,20);pintaHist()};
async function datos(){const r=await j('/api/datos?mun='+encodeURIComponent($('fmun').value));$('dinfo').textContent=r.info;
 $('datos').innerHTML='<thead><tr>'+r.cols.map(c=>`<th>${c}</th>`).join('')+'</tr></thead><tbody>'+r.rows.map(f=>'<tr>'+f.map(x=>`<td>${x}</td>`).join('')+'</tr>').join('')+'</tbody>'}
$('fmun').onchange=datos;
function graf(){const i=$('gsel').selectedIndex;$('gimg').src='/api/grafica?i='+i;$('gobs').textContent=I.obs[i]}
$('gsel').onchange=graf; let I;
(async()=>{I=await j('/api/init');opt($('mun'),I.mun,'LOS SANTOS');opt($('mes'),I.meses,I.meses[I.meses.length-1]);opt($('fmun'),['TODOS',...I.mun],'TODOS');
 $('arch').innerHTML=I.arch;opt($('gsel'),I.graf,I.graf[0]);$('met').textContent=I.met;datos();graf()})();
</script></body></html>"""


def texto_plano_metricas():
    t = texto_metricas(E["m"], E["imp"], E["tabla"])
    return t.replace("**", "").replace("### ", "").replace("_Nota:", "Nota:").replace("._", ".")


def info_inicio():
    df = E["df"]
    return {"mun": [x.replace("_", " ") for x in E["mun"]], "meses": E["meses"],
            "arch": (f"Archivo: <b>{E['archivo']}</b> · {E['n_crudo']} filas leídas · {len(df)} limpias · periodo "
                     f"{df['fecha_hora'].min().date()} a {df['fecha_hora'].max().date()} (el catálogo completo abarca ~20 años; este archivo cubre 2015-2018)"),
            "graf": [n for n, _ in GRAFS], "obs": OBSERVACIONES, "met": texto_plano_metricas()}


def datos_tabla(mun):
    df = E["df"]
    d = df if mun == "TODOS" else df[df["municipio"] == mun.replace(" ", "_")]
    d = d.sort_values("fecha_hora", ascending=False)
    t = d[COLS_DATOS].head(500).copy()
    t["fecha_hora"] = t["fecha_hora"].astype(str)
    t = t.fillna("")
    return {"info": f"{len(d)} sismos en {mun} (se muestran los 500 más recientes)", "cols": COLS_DATOS, "rows": t.astype(str).values.tolist()}


class Manejador(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _enviar(self, cuerpo, tipo):
        self.send_response(200)
        self.send_header("Content-Type", tipo)
        self.send_header("Content-Length", str(len(cuerpo)))
        self.end_headers()
        self.wfile.write(cuerpo)

    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        try:
            if u.path == "/":
                self._enviar(PAGINA.encode("utf-8"), "text/html; charset=utf-8")
            elif u.path == "/api/init":
                self._enviar(json.dumps(info_inicio(), ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
            elif u.path == "/api/clasificar":
                self._enviar(json.dumps(clasificar(E, q["mun"], q["mes"]), ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
            elif u.path == "/api/datos":
                self._enviar(json.dumps(datos_tabla(q.get("mun", "TODOS")), ensure_ascii=False).encode("utf-8"), "application/json; charset=utf-8")
            elif u.path == "/api/grafica":
                self._enviar(png(GRAFS[int(q.get("i", 0))][1]), "image/png")
            else:
                self.send_error(404)
        except Exception as e:                      # nunca tumbar el servidor por una consulta
            print("Error en la consulta:", repr(e))
            self.send_error(500)


def lanzar():
    print("Cargando el Excel y entrenando el modelo (unos segundos)...")
    E.update(preparar())
    GRAFS.extend(graficas(E))
    m = E["m"]
    print(f"Listo: {E['n_crudo']} sismos leídos, {len(E['df'])} limpios, {len(E['tabla'])} observaciones municipio-mes.")
    print(f"Exactitud prueba: {m['acc']:.3f} | F1 macro: {m['f1']:.3f}")
    servidor = None
    for puerto in range(8765, 8785):
        try:
            servidor = ThreadingHTTPServer(("127.0.0.1", puerto), Manejador)
            break
        except OSError:
            continue
    if servidor is None:
        sys.exit("No se pudo abrir un puerto local. Cierre otros programas e intente de nuevo.")
    url = f"http://127.0.0.1:{servidor.server_address[1]}"
    print(f"\nInterfaz lista en {url}  (se abre sola en el navegador). Para cerrar: Ctrl+C en esta terminal.")
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        servidor.serve_forever()
    except KeyboardInterrupt:
        print("\nCerrado.")


if __name__ == "__main__":
    lanzar()
