

const $ = id => document.getElementById(id);
const NIVELES = ['bajo', 'medio', 'alto'];
const nombresVisibles = D.mun.map(x => x.replace(/_/g, ' '));
const fmt = x => x.toFixed(2).replace('.', ',');
let historial = [];


function llenarSelect(sel, valores, elegido) {
  sel.innerHTML = '';
  valores.forEach(v => {
    const o = document.createElement('option');
    o.textContent = v;
    if (v === elegido) o.selected = true;
    sel.appendChild(o);
  });
}
function guardar(clave, valor) { try { localStorage.setItem(clave, valor); } catch (e) {} }
function leer(clave) { try { return localStorage.getItem(clave); } catch (e) { return null; } }


document.querySelectorAll('.pestanas button').forEach(boton => {
  boton.onclick = () => {
    document.querySelectorAll('.pestanas button').forEach(b => b.classList.remove('activa'));
    document.querySelectorAll('.panel').forEach(p => p.classList.remove('activo'));
    boton.classList.add('activa');
    $(boton.dataset.panel).classList.add('activo');
  };
});

function aplicarTono(nombre) {
  document.body.className = 'tono-' + nombre;
  $('tono').value = nombre;
  guardar('tono_sismos', nombre);
}
$('tono').onchange = () => aplicarTono($('tono').value);
const tonoGuardado = leer('tono_sismos');
if (tonoGuardado) aplicarTono(tonoGuardado);


try { historial = JSON.parse(leer('historial_sismos') || '[]'); } catch (e) { historial = []; }
function pintarHistorial() {
  $('historial').innerHTML = '';
  historial.forEach(fila => {
    const tr = document.createElement('tr');
    fila.forEach(x => { const td = document.createElement('td'); td.textContent = x; tr.appendChild(td); });
    $('historial').appendChild(tr);
  });
}
$('borrar-btn').onclick = () => { historial = []; guardar('historial_sismos', '[]'); pintarHistorial(); };


function mostrarBarras(prob) {
  NIVELES.forEach((n, i) => {
    const v = prob ? prob[i] * 100 : 0;
    $('barra-' + n).style.width = v + '%';
    $('pct-' + n).textContent = v.toFixed(0) + '%';
  });
}
function mostrarNivel(texto, clase) {
  $('nivel').textContent = texto;
  $('nivel').className = 'nivel' + (clase ? ' nivel-' + clase : '');
}

$('clasificar-btn').onclick = () => {
  const mun = $('mun').value, mes = $('mes').value;
  const clave = mun.replace(/ /g, '_') + '|' + mes;
  const hora = new Date().toLocaleTimeString();
  const hubo = D.act[clave];     
  const p = D.pred[clave];      
  let fila;

  if (!hubo) {
    mostrarBarras(null); mostrarNivel('—', '');
    $('resultado').textContent = 'No hay sismos registrados en ' + mun + ' durante ' + mes + '.';
    fila = [hora, mun, mes, 'sin datos', '-', '-'];
  } else if (!p) {
    mostrarBarras(null); mostrarNivel('—', '');
    $('resultado').textContent = mes + ' es el primer mes del catálogo: no hay mes previo para clasificar ' + mun + '.';
    fila = [hora, mun, mes, 'sin datos', '-', '-'];
  } else {
    const prob = p.slice(0, 3);
    const pred = NIVELES[prob.indexOf(Math.max(...prob))];
    const real = NIVELES[p[3]];
    const conjunto = p[6] === 1 ? 'entrenamiento' : 'prueba';
    mostrarBarras(prob); mostrarNivel(pred.toUpperCase(), pred);
    $('resultado').textContent =
      'Nivel predicho: ' + pred.toUpperCase() + '\n' +
      'Nivel real del catálogo: ' + real.toUpperCase() + ' (mayor sismo del mes: M ' + p[4].toFixed(1) + ', ' + p[5] + ' sismos)\n' +
      'Conjunto: ' + conjunto + (conjunto === 'prueba' ? ' (el modelo NO lo vio al entrenar)' : '');
    fila = [hora, mun, mes, pred.toUpperCase(), real.toUpperCase(), conjunto];
  }
  historial.unshift(fila);
  historial = historial.slice(0, 20);
  guardar('historial_sismos', JSON.stringify(historial));
  pintarHistorial();
};


function pintarDatos() {
  const filtro = $('filtro-mun').value;
  const idx = filtro === 'TODOS' ? -1 : nombresVisibles.indexOf(filtro);
  const filas = [];
  let total = 0;
  D.ev.forEach(r => {
    if (idx === -1 || r[1] === idx) { total++; if (filas.length < 500) filas.push(r); }
  });
  $('datos-info').textContent = total.toLocaleString('es') + ' sismos en ' + filtro + ' (se muestran los 500 más recientes)';
  $('tabla-datos').innerHTML = '';
  filas.forEach(r => {
    const tr = document.createElement('tr');
    r.forEach((x, i) => {
      const td = document.createElement('td');
      td.textContent = i === 1 ? nombresVisibles[x] : (x === null ? '' : x);
      tr.appendChild(td);
    });
    $('tabla-datos').appendChild(tr);
  });
}
$('filtro-mun').onchange = pintarDatos;


function pintarGrafica() {
  const g = D.graf[$('grafica-sel').selectedIndex];
  $('grafica-img').src = g.img;
  $('grafica-obs').textContent = g.obs;
}
$('grafica-sel').onchange = pintarGrafica;



function pintarMetricas() {
  const m = D.m;
  $('m-acc').textContent = fmt(m.acc);
  $('m-f1').textContent = fmt(m.f1);
  $('m-obs').textContent = D.n_obs;
  $('m-split').textContent = m.n_train + ' / ' + m.n_test;
  $('r-may-acc').textContent = fmt(m.acc_may); $('r-may-f1').textContent = fmt(m.f1_may);
  $('r-per-acc').textContent = fmt(m.acc_per); $('r-per-f1').textContent = fmt(m.f1_per);
  $('r-mod-acc').textContent = fmt(m.acc);     $('r-mod-f1').textContent = fmt(m.f1);
  $('c-bajo').textContent = D.clases[0]; $('c-medio').textContent = D.clases[1]; $('c-alto').textContent = D.clases[2];

  $('tabla-nivel').innerHTML = '';
  NIVELES.forEach(n => {
    const r = m.rep[n], tr = document.createElement('tr');
    [n, fmt(r[0]), fmt(r[1]), fmt(r[2]), r[3]].forEach(x => { const td = document.createElement('td'); td.textContent = x; tr.appendChild(td); });
    $('tabla-nivel').appendChild(tr);
  });
  m.matriz.forEach((fila, i) => fila.forEach((v, j) => { $('mx-' + i + '-' + j).textContent = v; }));

  $('importancias').innerHTML = '';
  m.imp.forEach(([nombre, valor]) => {
    const f = document.createElement('div'); f.className = 'fila-barra';
    f.innerHTML = '<span class="etiqueta"></span><div class="pista"><div class="relleno principal"></div></div><span class="valor"></span>';
    f.querySelector('.etiqueta').textContent = nombre;
    f.querySelector('.relleno').style.width = Math.min(100, valor * 600) + '%';
    f.querySelector('.valor').textContent = fmt(valor);
    $('importancias').appendChild(f);
  });
}



function pintarMetodo() {
  $('archivo-info').innerHTML = 'Archivo: <b></b> · ' + D.n_crudo.toLocaleString('es') + ' filas leídas · ' +
    D.n_limpio.toLocaleString('es') + ' limpias · periodo ' + D.periodo[0] + ' a ' + D.periodo[1];
  $('archivo-info').querySelector('b').textContent = D.archivo;
  $('periodo').textContent = 'Periodo disponible: ' + D.periodo[0] + ' a ' + D.periodo[1] + ' · ' + D.mun.length + ' municipios.';
  $('limpieza').textContent = D.n_crudo.toLocaleString('es') + ' filas originales → ' + D.n_limpio.toLocaleString('es') +
    ' sismos limpios → ' + D.n_obs + ' observaciones municipio-mes para el modelo.';
}



llenarSelect($('mun'), nombresVisibles, 'LOS SANTOS');
llenarSelect($('mes'), D.meses, D.meses[D.meses.length - 1]);
llenarSelect($('filtro-mun'), ['TODOS'].concat(nombresVisibles), 'TODOS');
llenarSelect($('grafica-sel'), D.graf.map(g => g.n), D.graf[0].n);
pintarHistorial(); pintarDatos(); pintarGrafica(); pintarMetricas(); pintarMetodo();
